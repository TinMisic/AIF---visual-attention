height = 64
width = 64
channels = 3

latent_size = 100
# learning_rate = 0.001
# step_size = 20
# gamma = 0.95
variance = 1/height
# n_epochs = 100
n_batch = 128
beta = 1

# latent_mode = "pure" # "pure" = no orientation in latent space | "orient" = orientation present in latent space
