import torch
import torchvision
import matplotlib.pyplot as plt

vae = torch.load("vae.pt")
imgs = vae.sample(n=49)
grid = torchvision.utils.make_grid(imgs, nrow=7)
plt.show(grid.permute(1, 2, 0))
