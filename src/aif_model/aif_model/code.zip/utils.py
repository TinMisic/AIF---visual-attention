import torch
from torch.utils import data
import numpy as np
from pathlib import Path
from PIL import Image
import torchvision
import config as c

# Define dataset class
class Dataset(data.Dataset):
    def __init__(self, images_root, orientation_path, size = 20000):
        self.imgPaths = list(Path(images_root).rglob('img*.jpg'))
        self.orientation = np.genfromtxt(orientation_path, delimiter=',')
        length = min(size,len(self.imgPaths))

        self.orientation = self.orientation[:length,:]
        self.imgPaths = self.imgPaths[:length]

    def __len__(self):
        return len(self.imgPaths)

    def __getitem__(self, i):
        sample = None
        with Image.open(self.imgPaths[i]) as img:
            try:
                #img = img.resize((c.width,c.height))
                t = torchvision.transforms.functional.pil_to_tensor(img)
                tMin = torch.min(t)
                tMax = torch.max(t) - tMin
                tMax = max(tMax, 1e-8)
                t = (t - tMin) / (tMax) # Scaling to [-1, 1]
                sample=t
            except OSError:
                return self.__getitem__(i-1) # return previous image

        # normalize ball position   
        lat_rep = np.zeros(c.latent_size)
        lat_rep[0] = self.orientation[i][0]/c.width
        lat_rep[1] = self.orientation[i][1]/c.height

        return sample, lat_rep
    
# Split dataset in train/test set and in batches
def split_dataset(dataset, percent):
    length = int(dataset.__len__()*percent)
    train_set, test_set = data.random_split(dataset, (length, dataset.__len__() - length))
    train_gen = data.DataLoader(train_set, batch_size=c.n_batch, shuffle=True, num_workers=4)
    test_gen = data.DataLoader(test_set, batch_size=c.n_batch,num_workers=4)

    return train_gen, test_gen

def kl_divergence(p_m, p_v, q_m, log_q_v):
    return torch.mean(0.5 * torch.sum(torch.log(p_v) - log_q_v + (log_q_v.exp() + (q_m - p_m) ** 2) / p_v - 1, dim=1), dim=0)
